// let this.#current_time = Date.now()

const MS_IN_SECOND = 1000
const MS_IN_MINUTE = 60 * 1000
const MS_IN_HOUR = 60 * 60 * 1000

// let this.#interval = 5000

/**
 * @param {Date} time 
 */
const getWatchTime = (time) => {
    let hours = time.getHours()
    let min = time.getMinutes()
    let sec = time.getSeconds()
    
    if(min < 10)
        min = '0' + min

    if(hours < 10)
        hours = '0' + hours

    if(sec < 10)
        sec = '0' + sec

    return `${hours}:${min}:${sec}`
}


class DateTimer{
    #current_time
    #interval
    #callbacks


    /**
     * 
     * @param {number} interval 
     * @param {Function[]} callbacks 
     */
    constructor(interval, callbacks) {
        this.#current_time = Date.now()
        this.#interval = interval

        
        this.#callbacks = callbacks
    }

    #timer_handler(current_time){
        let delta = Date.now() - current_time
        current_time = current_time + this.#interval
        setTimeout(() => {this.#timer_handler(current_time)}, this.#interval - delta)
        
        console.log(getWatchTime(new Date(current_time)))
        console.log(`delta = ${delta}`)
    }

    start(){
        this.#current_time = Date.now()
        setTimeout(() => {
            this.#timer_handler(this.#current_time)
        }, 0)
    }


}


// const dateTimer = new DateTimer(10000)
// dateTimer.start()

const october = [
    {category: 'Кофе', val: 700},
    {category: 'Газ', val: 200},
    {category: 'Овсянка', val: 200},
    {category: 'Чай', val: 500},
]

const november = [
    {category: 'Чай', val: 430},
    {category: 'Овсянка', val: 180},
    {category: 'Газ', val: 170},
    {category: 'Отопление', val: 3200},
    {category: 'Кофе', val: 500},
]
    

const mergeArrayOfObjects = (arrOfObj1, arrOfObj2, key, val_key) => {
    
    /* 
        arr_1 = ['Кофе', 'Газ', 'Овсянка', 'Чай']
    */
    // const mergeObj = (arrOfObj) => {
    //     const outObj = arrOfObj.map((obj) => {
    //         return { [obj[key]]: obj[val_key] }
    //     })

    //     return outObj
    // }

    const transformObj = (arrOfObj) => {
        const new_obj = {}

        arrOfObj.forEach((obj, ind) => {
            const new_key = obj[key]
            new_obj[new_key] = ind
        })

        return new_obj
    }

    const keyIndexObj = transformObj(arrOfObj2)

    
    const output = arrOfObj1.map(obj => {
        const newKey = obj[key]
        let newVal = obj[val_key]

        const indexInSecondObject = keyIndexObj[newKey]
        const valInSecondObject = arrOfObj2[indexInSecondObject][val_key]

        newVal += valInSecondObject
        
        return{
            [newKey]: newVal
        }
    })

    const keyIndexObj1 = transformObj(arrOfObj1)
    const keyIndexObj2 = transformObj(arrOfObj2)


    // console.log(output)
    console.log(keyIndexObj1)
    console.log(keyIndexObj2)
    
    // console.log(transformObj(arrOfObj2))

    

    // console.log(mergeObj(arrOfObj1))
    // console.log(mergeObj(arrOfObj2))
    // console.log('dsa')
    


}

mergeArrayOfObjects(october, november, 'category', 'val')
